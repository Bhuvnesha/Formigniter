<div id="footer">
	<div style="float: right;">
		Created by <a href="http://toomanytabs.com">Ollie Rattue</a> <a href="http://twitter.com/ollierattue"><img 
		src="http://toomanytabs.com/blog/wp-content/themes/k2/images/Twitter-16x16.png" 
		style="vertical-align:middle;border:0;margin-left: 4px;" alt="Follow Ollie Rattue on twitter" /></a>
	</div>       
</div>	
</div>

<a href="http://github.com/ollierattue/FormIgniter"><img style="position: absolute; top: 0; right: 0; border: 0;" src="<?php echo base_url();?>assets/images/formigniter/ribbons_source_code.png" alt="Source code on GitHub"></a>

</body>
</html>