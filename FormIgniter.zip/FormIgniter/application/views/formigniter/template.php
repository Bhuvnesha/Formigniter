<?php // template used by formigniter
$this->load->view('formigniter/header');
$this->load->view("formigniter/{$page}");
$this->load->view('formigniter/footer');
?>