FormIgniter readme file

http://formigniter.org/
Ollie Rattue - orattue[at]toomanytabs.com

Codeigniter form files:

controller - myform.php
view - myform_view.php
model - myform_model.php
sql - sql.php

Load the MVC files into /system/application/ in the relevant directories.

Build the database using the sql either running it directly from the command line or importing using a tool such a phpMyAdmin.

Make sure you have the correct settings in your database configuration file at /system/application/config/database.php

Formigniter takes away the drudge work of building your forms. You can now go on to build the more interesting custom elements, session controls and data manipulation.

I hope this has made your life a little easier!
